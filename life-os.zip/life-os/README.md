# Life OS

A single-page PWA for Charlie — built around one question: **what's next.**

Mobile-first. Dark mode only. Offline. No accounts. All data lives on your phone.

## What's in it

- **Today** — Dashboard. Next meal, top chore, top business action, 5-min win, counters.
- **Food** — Pre-loaded meal plan (~3,200 kcal/day), one-tap logging, shopping list grouped by store, fortnightly £75 food budget.
- **Tidy** — Rotating chores. Surfaces the most overdue. No shame language.
- **Work** — Inhance Media client pipeline (Lead → Invoiced) + R&R Property jobs with one-tap directions and weekly earnings.
- **Me** — Sub-tabs:
  - **Money** — Simple in/out ledger, weekly/monthly totals, overspend flags.
  - **Habits** — Joints / gym / water / supplements. Trends, no targets you have to hit.
  - **Private** — PIN-locked notes for court / mediation / anything sensitive.

## Tech

Vite · React 18 · TypeScript · Tailwind · Zustand · Dexie (IndexedDB) · Recharts · Lucide · vite-plugin-pwa.

No backend. No accounts. No cloud sync. Everything is in IndexedDB on the device.

## Run it

```bash
npm install
npm run dev
```

Then open `http://localhost:5173` (Vite will print the LAN URL too — open that on your S23 to test on-device).

## Build for production / install as PWA

```bash
npm run build
npm run preview
```

To install on Android:
1. Build and serve over HTTPS (or use `npm run preview` on LAN — Chrome lets you install over `http://` on localhost only).
2. Open the URL in Chrome on your S23.
3. Tap the three-dot menu → **Install app**.
4. The Life OS icon appears on your home screen. Tap it — it opens full-screen, no browser chrome.

For production deployment: Netlify, Vercel, or Cloudflare Pages will host this for free. Connect a git repo and they auto-build on push.

## How to test each module

The app seeds on first launch. To re-seed, open DevTools → Application → IndexedDB → delete the `life-os` database, then refresh.

### 1. Today (the dashboard)

- Open the app — you should land on Today. Greeting reflects the time of day.
- **Next meal**: tap the meal card → it should mark logged and the next slot appears.
- **Top chore**: tap it → it disappears (rotated to "on track"), the next overdue takes its place.
- **Top business**: tap → routes you to the Inhance pipeline.
- **5-min win**: tap the refresh icon on the card → picks a different one.
- **Counters row**:
  - Water tile: tap → counter goes up. Same for joints.
  - kcal tile: tap → jumps to Food.
- **Pull-to-refresh**: from the very top of the screen, pull down ~50px → haptic + counters re-prioritise.

### 2. Food

- **Today view**: 4 meal cards (breakfast, lunch, dinner, snack). Tap to log. Tap again to undo. Total updates instantly.
- **Plan view**: full ingredients per meal, with the store next to each item.
- **Shop view**: shopping list = only the ingredients for meals you *haven't* logged yet, grouped by Aldi / Lidl / Food Warehouse / Booker / Other.
- **Budget view**: pick a store, type the amount, tap Add. Total goes up. When you cross £75 in 14 days the bar turns red.
- **Log something else**: bottom of Today view — custom snack with kcal.

### 3. Tidy

- One chore highlighted at the top with "Next move" eyebrow.
- Tap **Done** → it resets the timer, moves to "On track" at the bottom, and a new chore takes the top slot.
- "Also due" shows other overdue items — tap the checkmark to mark done.
- On "On track" items, tap the rotate icon → resets to never done (useful if you forgot to log).
- Try waiting 2 days on a daily chore (or set your phone clock forward) — it moves from "On track" back up to "Next move".

### 4. Work

Two sub-tabs: Inhance Media and R&R Property.

**Inhance Media:**
- Three example clients seeded: Scratby Static Caravan (booked), Southwold Coastal Cottage (contacted), The Anchor Café (lead).
- Tap the next-stage button on a card → advances Lead → Contacted → Booked → Shot → Delivered → Invoiced. Last-contact timestamp updates.
- "Log contact" → just bumps the last-contact date.
- Pencil icon → opens the editor. Edit any field. Delete from inside the editor.
- "+" top-right → New lead. Add a name + minimal info → appears in the pipeline.
- Filter chips at the top show counts per stage.

**R&R Property:**
- Three jobs seeded for today: Seaview Cottage (£65), Dune Lodge (£75), Anchor Cottage (£120).
- Tap the address on a card → opens Google Maps directions in your default app.
- Tap "Mark done" → moves to "Done" group, week total updates.
- "+" top-right → New job. Pick a date, type (changeover/deep/maintenance/other), and fee.
- "History" tab → previous 2 weeks grouped by date, with daily total earnings.

### 5. Me → Money

- Two prominent cards: This week net, This month net (income − expenses).
- "Money in" → categories: UC, Inhance, R&R, Other.
- "Money out" → categories: Food, Fuel, Gear, Bills, Joints, Other.
- If food spend > £75 in the last 14 days, or fuel > £40 this week, a yellow warning card appears at top.
- Each ledger row has a trash icon to delete.

### 6. Me → Habits

- 4 counters: Gym (target 4/wk), Water (target 8 glasses/day), Joints (no target), Supplements (1/day).
- Tap + to log, tap − to undo.
- 7-day joints bar chart at the bottom — just shows the trend, no shame, no streak penalties.

### 7. Me → Private

- First time opening: prompts you to set a PIN (4+ digits).
- After that: prompts for PIN. Wrong PIN gives an error.
- Inside: tap + to add a note. Title + body. Save.
- Tap a note to edit. Delete from inside the editor.
- Tap the lock icon top-right to lock it again.
- **Note**: this is local obfuscation (XOR + base64) — not real encryption. Anyone with raw IndexedDB access could decode it. It keeps a casual onlooker out if your phone is briefly unlocked, but for genuine privacy use Samsung Secure Folder.

## Files map

```
src/
├── App.tsx                 // Tab routing + seed on first launch
├── main.tsx                // React entry
├── index.css               // Tailwind + brand tokens + animations
├── db/
│   ├── schema.ts           // Dexie tables + TypeScript types
│   └── seed.ts             // Meal plan, chores, example clients/jobs
├── store/
│   └── appStore.ts         // Zustand: active tab, sub-tabs, refresh trigger
├── components/
│   ├── BottomNav.tsx       // 5-tab bottom navigation
│   ├── Card.tsx            // Card + CardButton primitives
│   ├── SectionHeader.tsx   // Eyebrow + display heading
│   └── EmptyState.tsx      // "Pick one thing" empty surfaces
├── modules/
│   ├── Today.tsx           // Dashboard — the "next move" surface
│   ├── Food.tsx            // Plan, log, shop, budget
│   ├── Tidy.tsx            // Chore rotation
│   ├── Business.tsx        // Inhance + R&R (combined module)
│   ├── Money.tsx           // Ledger
│   ├── Habits.tsx          // Counters + 7d trend
│   ├── Private.tsx         // PIN-locked notes
│   └── Me.tsx              // Sub-tab container for Money/Habits/Private
├── hooks/
│   └── useHaptic.ts        // Vibration API wrapper
├── lib/
│   └── crypto.ts           // PIN-derived XOR obfuscation (local only)
└── utils/
    ├── date.ts             // startOfDay, daysSince, relativeDay…
    └── currency.ts         // gbp() formatter
```

## Design decisions I made for you

- **"Me" tab combines Money + Habits + Private** as sub-tabs — the brief asked for max 5 bottom-nav icons, and these three are personal-side concerns.
- **Business is one tab with Inhance/R&R as sub-tabs** for the same reason.
- **Fonts**: Fraunces (display) + Geist (body) loaded from Google Fonts, cached by the service worker for offline. Both fall back to system fonts if offline before they're cached.
- **PIN crypto** is intentionally light — real crypto on a non-keychain device would need WebCrypto + careful key derivation, and the "if someone has your unlocked phone they can pwn it anyway" threat model makes the extra complexity questionable. Easy to swap to WebCrypto's `SubtleCrypto.encrypt` with PBKDF2 later — the interface in `src/lib/crypto.ts` is just two functions (`obfuscate`, `deobfuscate`).
- **No Google Calendar integration** for R&R — the brief flagged it as a stretch and offline-first is hard to do with OAuth flows. Manual entry is fast (< 5 taps per job). If you want this later, look at the Google Calendar API's free/busy endpoint with a long-lived refresh token cached locally.
- **Counters reset by date**, not time — water, joints, kcal all roll over at midnight (system local time). Reopen the app to see the new day; the queries cache for the session.
- **Pull-to-refresh** on Today only — the other modules don't need re-prioritisation.
- **Haptic** patterns: 8ms tap, [10,30,12] success, [20,40,20] warn. Subtle.

## Things you might want to tweak

- **Kcal target** (3200): change in DevTools or add a settings screen later. Stored at `kv: 'kcal_target'`.
- **Food budget** (£75/fortnight): stored at `kv: 'food_budget_fortnight'`.
- **Fuel weekly limit** (£40): hardcoded in `Money.tsx` — pull into kv if you want to edit from UI.
- **Add a chore / meal**: I didn't build form UIs for these. Easy to add — clone the `JobForm` component pattern. Currently you can add them via DevTools → IndexedDB → `life-os` → `chores`/`plan` tables.

## Backup your data

Open DevTools → Application → IndexedDB → `life-os` → export each table. Or add an export button using `Dexie.exportDB` (`dexie-export-import` plugin) when this matters.

— Built end-to-end, ready to maintain.
