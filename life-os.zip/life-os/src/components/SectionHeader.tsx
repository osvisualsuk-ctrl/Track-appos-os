import { type ReactNode } from 'react'

export function SectionHeader({
  eyebrow,
  title,
  right
}: {
  eyebrow?: string
  title: string
  right?: ReactNode
}) {
  return (
    <div className="flex items-end justify-between mb-3">
      <div>
        {eyebrow && (
          <div className="text-xxs uppercase tracking-[0.18em] text-gold/80 mb-1">
            {eyebrow}
          </div>
        )}
        <h2 className="display-heading text-2xl text-cream">{title}</h2>
      </div>
      {right}
    </div>
  )
}
