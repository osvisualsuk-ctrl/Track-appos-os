import { Home, UtensilsCrossed, Sparkles, Briefcase, User } from 'lucide-react'
import { useAppStore, type Tab } from '../store/appStore'
import { haptic } from '../hooks/useHaptic'

const TABS: { id: Tab; label: string; Icon: typeof Home }[] = [
  { id: 'today', label: 'Today', Icon: Home },
  { id: 'food', label: 'Food', Icon: UtensilsCrossed },
  { id: 'tidy', label: 'Tidy', Icon: Sparkles },
  { id: 'business', label: 'Work', Icon: Briefcase },
  { id: 'me', label: 'Me', Icon: User }
]

export function BottomNav() {
  const tab = useAppStore((s) => s.tab)
  const setTab = useAppStore((s) => s.setTab)

  return (
    <nav
      className="fixed bottom-0 inset-x-0 z-30 safe-bottom
                 bg-forest-deep/95 backdrop-blur-md border-t border-cream/5"
    >
      <div className="max-w-md mx-auto grid grid-cols-5">
        {TABS.map(({ id, label, Icon }) => {
          const active = tab === id
          return (
            <button
              key={id}
              onClick={() => {
                if (tab !== id) haptic('tap')
                setTab(id)
              }}
              className="min-h-tap flex flex-col items-center justify-center gap-1 py-2 select-none"
              aria-label={label}
              aria-current={active ? 'page' : undefined}
            >
              <Icon
                size={22}
                strokeWidth={active ? 2.2 : 1.6}
                className={active ? 'text-gold' : 'text-cream/55'}
              />
              <span
                className={`text-xxs tracking-wide ${active ? 'text-gold' : 'text-cream/55'}`}
              >
                {label}
              </span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
