import { type ReactNode } from 'react'

export function EmptyState({
  title = 'Pick one thing',
  hint,
  action
}: {
  title?: string
  hint?: string
  action?: ReactNode
}) {
  return (
    <div className="card p-6 text-center">
      <div className="display-heading text-xl text-cream mb-1">{title}</div>
      {hint && <p className="text-sm text-cream-dim mb-4">{hint}</p>}
      {action}
    </div>
  )
}
