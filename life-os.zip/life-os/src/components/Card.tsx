import { type ReactNode, type HTMLAttributes } from 'react'

interface CardProps extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode
  prominent?: boolean
  as?: 'div' | 'button'
}

export function Card({ children, prominent, className = '', ...rest }: CardProps) {
  return (
    <div
      className={`${prominent ? 'card-prominent' : 'card'} p-4 ${className}`}
      {...rest}
    >
      {children}
    </div>
  )
}

export function CardButton({
  children,
  prominent,
  className = '',
  ...rest
}: CardProps & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      className={`${prominent ? 'card-prominent' : 'card'} p-4 text-left w-full active:scale-[0.99] transition-transform ${className}`}
      {...rest}
    >
      {children}
    </button>
  )
}
