import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import './index.css'

const root = createRoot(document.getElementById('root')!)
root.render(
  <StrictMode>
    <App />
  </StrictMode>
)

// Register PWA SW (handled by vite-plugin-pwa autoUpdate)
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    // The plugin auto-injects the registration script in production.
    // No-op here in dev.
  })
}
