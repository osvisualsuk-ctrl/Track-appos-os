// NOTE: This is local-only obfuscation, not real cryptography.
// It keeps casual eyes out if someone unlocks your phone briefly.
// For real privacy use phone-level security (Secure Folder etc.).

const enc = (s: string) => new TextEncoder().encode(s)

const xor = (data: Uint8Array, key: Uint8Array) => {
  const out = new Uint8Array(data.length)
  for (let i = 0; i < data.length; i++) out[i] = data[i] ^ key[i % key.length]
  return out
}

const b64 = (bytes: Uint8Array) => {
  let s = ''
  for (const b of bytes) s += String.fromCharCode(b)
  return btoa(s)
}

const fromB64 = (s: string) => {
  const bin = atob(s)
  const out = new Uint8Array(bin.length)
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i)
  return out
}

export const obfuscate = (plain: string, pin: string) => {
  const key = enc(pin + '|life-os|salt')
  return b64(xor(enc(plain), key))
}

export const deobfuscate = (cipher: string, pin: string) => {
  try {
    const key = enc(pin + '|life-os|salt')
    const bytes = xor(fromB64(cipher), key)
    return new TextDecoder().decode(bytes)
  } catch {
    return ''
  }
}

// PIN verification: store a known token encrypted with the PIN.
export const TOKEN_PLAIN = 'life-os-ok'
