import { useEffect, useState } from 'react'
import { useAppStore } from './store/appStore'
import { BottomNav } from './components/BottomNav'
import Today from './modules/Today'
import Food from './modules/Food'
import Tidy from './modules/Tidy'
import Business from './modules/Business'
import Me from './modules/Me'
import { seedIfEmpty } from './db/seed'

export default function App() {
  const tab = useAppStore((s) => s.tab)
  const [ready, setReady] = useState(false)

  useEffect(() => {
    seedIfEmpty().finally(() => setReady(true))
  }, [])

  if (!ready) {
    return (
      <div className="min-h-dvh flex items-center justify-center text-cream-dim text-sm">
        <span className="display-heading text-2xl text-gold">Life OS</span>
      </div>
    )
  }

  return (
    <div className="min-h-dvh safe-top pb-24">
      <main className="max-w-md mx-auto px-4 pt-6">
        {tab === 'today' && <Today />}
        {tab === 'food' && <Food />}
        {tab === 'tidy' && <Tidy />}
        {tab === 'business' && <Business />}
        {tab === 'me' && <Me />}
      </main>
      <BottomNav />
    </div>
  )
}
