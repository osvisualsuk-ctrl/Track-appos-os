export const startOfDay = (d: Date | number = new Date()) => {
  const x = new Date(d)
  x.setHours(0, 0, 0, 0)
  return x.getTime()
}

export const endOfDay = (d: Date | number = new Date()) => {
  const x = new Date(d)
  x.setHours(23, 59, 59, 999)
  return x.getTime()
}

export const ymd = (d: Date | number = new Date()) => {
  const x = new Date(d)
  const y = x.getFullYear()
  const m = String(x.getMonth() + 1).padStart(2, '0')
  const day = String(x.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

export const daysSince = (ts: number | null) => {
  if (ts == null) return Infinity
  return Math.floor((Date.now() - ts) / 86400000)
}

export const relativeDay = (ts: number | null) => {
  if (ts == null) return 'never'
  const d = daysSince(ts)
  if (d === 0) return 'today'
  if (d === 1) return 'yesterday'
  if (d < 7) return `${d}d ago`
  if (d < 30) return `${Math.floor(d / 7)}w ago`
  return `${Math.floor(d / 30)}mo ago`
}

export const startOfWeek = (d: Date = new Date()) => {
  const x = new Date(d)
  const day = x.getDay() // 0 = Sun
  const diff = day === 0 ? -6 : 1 - day // make Monday the start
  x.setDate(x.getDate() + diff)
  x.setHours(0, 0, 0, 0)
  return x.getTime()
}

export const startOfMonth = (d: Date = new Date()) => {
  const x = new Date(d.getFullYear(), d.getMonth(), 1)
  return x.getTime()
}
