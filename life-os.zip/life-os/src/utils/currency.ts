export const gbp = (n: number) =>
  new Intl.NumberFormat('en-GB', {
    style: 'currency',
    currency: 'GBP',
    maximumFractionDigits: n % 1 === 0 ? 0 : 2
  }).format(n)
