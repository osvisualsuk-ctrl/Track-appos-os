import { create } from 'zustand'

export type Tab = 'today' | 'food' | 'tidy' | 'business' | 'me'
export type MeSub = 'money' | 'habits' | 'private'
export type BusinessSub = 'inhance' | 'rr'

interface AppState {
  tab: Tab
  meSub: MeSub
  businessSub: BusinessSub
  refreshSeed: number // bump to re-prioritise
  setTab: (t: Tab) => void
  setMeSub: (s: MeSub) => void
  setBusinessSub: (s: BusinessSub) => void
  bumpRefresh: () => void
}

export const useAppStore = create<AppState>((set) => ({
  tab: 'today',
  meSub: 'money',
  businessSub: 'inhance',
  refreshSeed: 0,
  setTab: (t) => set({ tab: t }),
  setMeSub: (s) => set({ meSub: s }),
  setBusinessSub: (s) => set({ businessSub: s }),
  bumpRefresh: () => set((s) => ({ refreshSeed: s.refreshSeed + 1 }))
}))
