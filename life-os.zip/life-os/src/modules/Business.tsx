import { useState, useMemo } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import {
  Plus,
  MapPin,
  Check,
  ChevronRight,
  Phone,
  Trash2,
  Pencil,
  X
} from 'lucide-react'
import {
  db,
  uid,
  type Client,
  type Job
} from '../db/schema'
import { startOfDay, endOfDay, startOfWeek, relativeDay } from '../utils/date'
import { gbp } from '../utils/currency'
import { Card, CardButton } from '../components/Card'
import { SectionHeader } from '../components/SectionHeader'
import { EmptyState } from '../components/EmptyState'
import { useAppStore } from '../store/appStore'
import { haptic } from '../hooks/useHaptic'

const STAGES: Client['stage'][] = [
  'lead',
  'contacted',
  'booked',
  'shot',
  'delivered',
  'invoiced'
]
const STAGE_LABEL: Record<Client['stage'], string> = {
  lead: 'Lead',
  contacted: 'Contacted',
  booked: 'Booked',
  shot: 'Shot',
  delivered: 'Delivered',
  invoiced: 'Invoiced'
}

export default function Business() {
  const sub = useAppStore((s) => s.businessSub)
  const setSub = useAppStore((s) => s.setBusinessSub)

  return (
    <div className="page-enter">
      <div className="flex gap-2 mb-4">
        <button
          onClick={() => setSub('inhance')}
          className={`flex-1 min-h-tap rounded-2xl text-sm font-medium ${
            sub === 'inhance'
              ? 'bg-gold text-forest-deep'
              : 'bg-cream/5 text-cream/70 border border-cream/10'
          }`}
        >
          Inhance Media
        </button>
        <button
          onClick={() => setSub('rr')}
          className={`flex-1 min-h-tap rounded-2xl text-sm font-medium ${
            sub === 'rr'
              ? 'bg-gold text-forest-deep'
              : 'bg-cream/5 text-cream/70 border border-cream/10'
          }`}
        >
          R&R Property
        </button>
      </div>

      {sub === 'inhance' ? <Inhance /> : <RR />}
    </div>
  )
}

// =============== Inhance pipeline ===============
function Inhance() {
  const clients =
    useLiveQuery(
      () => db.clients.where('business').equals('inhance').toArray(),
      []
    ) ?? []

  const [filter, setFilter] = useState<Client['stage'] | 'all'>('all')
  const [addOpen, setAddOpen] = useState(false)
  const [editing, setEditing] = useState<Client | null>(null)

  const filtered = useMemo(() => {
    const list = filter === 'all' ? clients : clients.filter((c) => c.stage === filter)
    return list.slice().sort((a, b) => {
      // Stage order, then most recent contact first
      const sa = STAGES.indexOf(a.stage)
      const sb = STAGES.indexOf(b.stage)
      if (sa !== sb) return sa - sb
      return (b.lastContact ?? 0) - (a.lastContact ?? 0)
    })
  }, [clients, filter])

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: clients.length }
    STAGES.forEach((s) => (map[s] = 0))
    clients.forEach((c) => map[c.stage]++)
    return map
  }, [clients])

  return (
    <>
      <SectionHeader
        eyebrow="Pipeline"
        title="Inhance Media"
        right={
          <button
            onClick={() => setAddOpen(true)}
            className="btn-icon size-11"
            aria-label="Add lead"
          >
            <Plus size={20} />
          </button>
        }
      />

      <div className="flex gap-2 mb-4 overflow-x-auto no-scrollbar pb-1">
        {(['all', ...STAGES] as const).map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`px-3 py-2 rounded-full text-xs whitespace-nowrap ${
              filter === s
                ? 'bg-gold text-forest-deep'
                : 'bg-cream/5 text-cream/70 border border-cream/10'
            }`}
          >
            {s === 'all' ? 'All' : STAGE_LABEL[s]}
            <span className="ml-1.5 opacity-70">{counts[s]}</span>
          </button>
        ))}
      </div>

      {addOpen && (
        <ClientForm
          onClose={() => setAddOpen(false)}
          onSave={async (data) => {
            await db.clients.add({
              ...data,
              id: uid(),
              createdAt: Date.now()
            })
            haptic('success')
            setAddOpen(false)
          }}
        />
      )}

      {editing && (
        <ClientForm
          initial={editing}
          onClose={() => setEditing(null)}
          onSave={async (data) => {
            await db.clients.update(editing.id, data)
            haptic('success')
            setEditing(null)
          }}
        />
      )}

      <div className="space-y-3">
        {filtered.length === 0 ? (
          <EmptyState
            title="Pick one thing"
            hint="Add a lead — even a half-name and a vibe is enough."
            action={
              <button onClick={() => setAddOpen(true)} className="btn-primary mx-auto">
                <Plus size={18} /> New lead
              </button>
            }
          />
        ) : (
          filtered.map((c) => (
            <ClientCard key={c.id} c={c} onEdit={() => setEditing(c)} />
          ))
        )}
      </div>
    </>
  )
}

function ClientCard({ c, onEdit }: { c: Client; onEdit: () => void }) {
  const advance = async () => {
    const i = STAGES.indexOf(c.stage)
    const next = STAGES[Math.min(STAGES.length - 1, i + 1)]
    await db.clients.update(c.id, { stage: next, lastContact: Date.now() })
    haptic('success')
  }
  const logContact = async () => {
    await db.clients.update(c.id, { lastContact: Date.now() })
    haptic('tap')
  }

  return (
    <Card>
      <div className="flex items-start gap-3">
        <div className="flex-1 min-w-0">
          <div className="text-xxs uppercase tracking-wider text-gold/80">
            {STAGE_LABEL[c.stage]}
            {c.subscription && c.subscription !== 'none' && (
              <span className="ml-2 text-cream/60">· {c.subscription}</span>
            )}
          </div>
          <div className="display-heading text-lg text-cream mt-0.5 truncate">{c.name}</div>
          {c.location && (
            <div className="text-xs text-cream-dim flex items-center gap-1 mt-0.5">
              <MapPin size={12} /> {c.location}
              {c.shootType && <span className="text-cream-muted">· {c.shootType}</span>}
            </div>
          )}
          {c.nextAction && (
            <div className="text-sm text-cream mt-2 flex items-start gap-1.5">
              <ChevronRight size={16} className="text-gold mt-0.5 shrink-0" />
              <span>{c.nextAction}</span>
            </div>
          )}
          <div className="text-xxs text-cream-muted mt-2">
            Last contact {relativeDay(c.lastContact)}
          </div>
        </div>
        <button onClick={onEdit} aria-label="Edit" className="btn-icon size-9">
          <Pencil size={14} />
        </button>
      </div>
      <div className="flex gap-2 mt-3">
        <button onClick={logContact} className="btn-ghost flex-1 text-sm">
          <Phone size={14} /> Log contact
        </button>
        {c.stage !== 'invoiced' && (
          <button onClick={advance} className="btn-primary flex-1 text-sm">
            <Check size={14} /> {STAGE_LABEL[STAGES[STAGES.indexOf(c.stage) + 1]]}
          </button>
        )}
      </div>
    </Card>
  )
}

function ClientForm({
  initial,
  onSave,
  onClose
}: {
  initial?: Client
  onSave: (data: Omit<Client, 'id' | 'createdAt'>) => void | Promise<void>
  onClose: () => void
}) {
  const [name, setName] = useState(initial?.name ?? '')
  const [location, setLocation] = useState(initial?.location ?? '')
  const [shootType, setShootType] = useState(initial?.shootType ?? '')
  const [stage, setStage] = useState<Client['stage']>(initial?.stage ?? 'lead')
  const [subscription, setSubscription] = useState<Client['subscription']>(
    initial?.subscription ?? 'none'
  )
  const [nextAction, setNextAction] = useState(initial?.nextAction ?? '')
  const [notes, setNotes] = useState(initial?.notes ?? '')

  const submit = () => {
    if (!name.trim()) return
    onSave({
      name: name.trim(),
      business: 'inhance',
      location: location.trim() || undefined,
      shootType: shootType.trim() || undefined,
      stage,
      subscription,
      nextAction: nextAction.trim() || undefined,
      lastContact: initial?.lastContact ?? Date.now(),
      notes: notes.trim() || undefined
    })
  }

  return (
    <div className="fixed inset-0 z-40 bg-forest-deep/95 backdrop-blur-sm overflow-y-auto safe-top safe-bottom">
      <div className="max-w-md mx-auto p-4 space-y-3">
        <div className="flex justify-between items-center mb-2">
          <h3 className="display-heading text-xl text-cream">
            {initial ? 'Edit lead' : 'New lead'}
          </h3>
          <button onClick={onClose} aria-label="Close" className="btn-icon size-11">
            <X size={20} />
          </button>
        </div>
        <input
          autoFocus
          className="input-field"
          placeholder="Name *"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          className="input-field"
          placeholder="Location (e.g. Southwold)"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
        />
        <input
          className="input-field"
          placeholder="Shoot type"
          value={shootType}
          onChange={(e) => setShootType(e.target.value)}
        />
        <div>
          <div className="text-xxs uppercase tracking-wider text-gold/80 mb-1.5">Stage</div>
          <div className="flex flex-wrap gap-1.5">
            {STAGES.map((s) => (
              <button
                key={s}
                onClick={() => setStage(s)}
                className={`px-3 py-2 rounded-full text-xs ${
                  stage === s ? 'bg-gold text-forest-deep' : 'bg-cream/5 text-cream/70'
                }`}
              >
                {STAGE_LABEL[s]}
              </button>
            ))}
          </div>
        </div>
        <div>
          <div className="text-xxs uppercase tracking-wider text-gold/80 mb-1.5">
            Subscription
          </div>
          <div className="flex gap-1.5">
            {(['none', 'monthly', 'quarterly'] as const).map((s) => (
              <button
                key={s}
                onClick={() => setSubscription(s)}
                className={`flex-1 px-3 py-2 rounded-full text-xs ${
                  subscription === s ? 'bg-gold text-forest-deep' : 'bg-cream/5 text-cream/70'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
        <input
          className="input-field"
          placeholder="Next action"
          value={nextAction}
          onChange={(e) => setNextAction(e.target.value)}
        />
        <textarea
          className="input-field py-3 min-h-[5rem]"
          placeholder="Notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
        />
        <div className="flex gap-2 pt-2">
          {initial && (
            <button
              onClick={async () => {
                await db.clients.delete(initial.id)
                haptic('warn')
                onClose()
              }}
              className="btn-ghost"
              aria-label="Delete"
            >
              <Trash2 size={18} />
            </button>
          )}
          <button onClick={onClose} className="btn-ghost flex-1">
            Cancel
          </button>
          <button onClick={submit} className="btn-primary flex-1">
            Save
          </button>
        </div>
      </div>
    </div>
  )
}

// =============== R&R jobs ===============
function RR() {
  const [view, setView] = useState<'today' | 'week'>('today')
  const [addOpen, setAddOpen] = useState(false)

  const today = useLiveQuery(
    () =>
      db.jobs
        .where('date')
        .between(startOfDay(), endOfDay(), true, true)
        .toArray(),
    []
  ) ?? []

  const weekEarnings = useLiveQuery(async () => {
    const since = startOfWeek()
    const all = await db.jobs.where('date').above(since - 1).toArray()
    return all.filter((j) => j.status === 'done').reduce((s, j) => s + j.fee, 0)
  }, []) ?? 0

  const todayDone = today.filter((j) => j.status === 'done')
  const todayPending = today.filter((j) => j.status === 'pending')

  return (
    <>
      <SectionHeader
        eyebrow="Holiday lets"
        title="R&R Property"
        right={
          <button onClick={() => setAddOpen(true)} className="btn-icon size-11" aria-label="Add job">
            <Plus size={20} />
          </button>
        }
      />

      <Card prominent className="mb-4">
        <div className="text-xxs uppercase tracking-wider text-cream-dim mb-1">
          This week (completed)
        </div>
        <div className="display-heading text-3xl text-cream">{gbp(weekEarnings)}</div>
        <div className="text-xs text-gold mt-1">
          {todayDone.length}/{today.length} jobs done today
        </div>
      </Card>

      <div className="flex gap-2 mb-4">
        <button
          onClick={() => setView('today')}
          className={`px-4 py-2 rounded-full text-sm ${
            view === 'today' ? 'bg-gold text-forest-deep' : 'bg-cream/5 text-cream/70'
          }`}
        >
          Today
        </button>
        <button
          onClick={() => setView('week')}
          className={`px-4 py-2 rounded-full text-sm ${
            view === 'week' ? 'bg-gold text-forest-deep' : 'bg-cream/5 text-cream/70'
          }`}
        >
          History
        </button>
      </div>

      {addOpen && <JobForm onClose={() => setAddOpen(false)} />}

      {view === 'today' &&
        (today.length === 0 ? (
          <EmptyState title="No jobs today" hint="Day off — or add one." />
        ) : (
          <div className="space-y-3">
            {todayPending.map((j, i) => (
              <JobCard key={j.id} j={j} routeIndex={i + 1} />
            ))}
            {todayDone.length > 0 && (
              <>
                <div className="text-xxs uppercase tracking-[0.18em] text-cream/40 mt-4 mb-2">
                  Done
                </div>
                {todayDone.map((j) => (
                  <JobCard key={j.id} j={j} routeIndex={0} />
                ))}
              </>
            )}
          </div>
        ))}

      {view === 'week' && <JobsHistory />}
    </>
  )
}

function JobCard({ j, routeIndex }: { j: Job; routeIndex: number }) {
  const isDone = j.status === 'done'
  const mapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(j.address)}`

  const toggle = async () => {
    await db.jobs.update(j.id, { status: isDone ? 'pending' : 'done' })
    haptic(isDone ? 'tap' : 'success')
  }

  return (
    <Card className={isDone ? 'opacity-60' : ''}>
      <div className="flex items-start gap-3">
        {routeIndex > 0 && (
          <div className="size-8 rounded-full bg-gold/20 text-gold flex items-center justify-center shrink-0 font-medium text-sm">
            {routeIndex}
          </div>
        )}
        {routeIndex === 0 && (
          <div className="size-8 rounded-full bg-ok/20 text-ok flex items-center justify-center shrink-0">
            <Check size={16} />
          </div>
        )}
        <div className="flex-1 min-w-0">
          <div className="flex justify-between items-start gap-2">
            <div className={`font-medium truncate ${isDone ? 'line-through text-cream-muted' : 'text-cream'}`}>
              {j.clientName}
            </div>
            <div className="text-gold text-sm font-medium shrink-0">{gbp(j.fee)}</div>
          </div>
          <a
            href={mapsUrl}
            target="_blank"
            rel="noopener"
            className="text-xs text-cream-dim flex items-center gap-1 mt-0.5"
          >
            <MapPin size={12} /> {j.address}
          </a>
          <div className="text-xxs text-cream-muted mt-1 uppercase tracking-wider">
            {j.type}
          </div>
          {j.notes && <p className="text-xs text-cream/80 mt-2">{j.notes}</p>}
        </div>
      </div>
      <button
        onClick={toggle}
        className={`w-full mt-3 min-h-tap rounded-full font-medium text-sm ${
          isDone
            ? 'bg-cream/5 text-cream/70 border border-cream/10'
            : 'bg-gold text-forest-deep'
        }`}
      >
        {isDone ? 'Mark pending' : 'Mark done'}
      </button>
    </Card>
  )
}

function JobsHistory() {
  const since = startOfWeek() - 14 * 86400000
  const all = useLiveQuery(
    () =>
      db.jobs
        .where('date')
        .between(since, endOfDay(), true, true)
        .reverse()
        .sortBy('date'),
    [since]
  ) ?? []

  if (all.length === 0)
    return <EmptyState title="No history yet" hint="Add a job to start tracking." />

  // Group by date
  const groups = all.reduce<Record<string, Job[]>>((acc, j) => {
    const k = new Date(j.date).toDateString()
    ;(acc[k] ??= []).push(j)
    return acc
  }, {})

  return (
    <div className="space-y-4">
      {Object.entries(groups).map(([day, jobs]) => {
        const total = jobs.filter((j) => j.status === 'done').reduce((s, j) => s + j.fee, 0)
        return (
          <div key={day}>
            <div className="text-xxs uppercase tracking-[0.18em] text-gold/70 mb-2 flex justify-between">
              <span>{day}</span>
              <span className="text-cream-dim normal-case tracking-normal">{gbp(total)}</span>
            </div>
            <div className="space-y-2">
              {jobs.map((j) => (
                <Card key={j.id} className="flex items-center gap-3">
                  <div className="flex-1 min-w-0">
                    <div className={`text-sm ${j.status === 'done' ? 'text-cream' : 'text-cream-dim'}`}>
                      {j.clientName}
                    </div>
                    <div className="text-xxs text-cream-muted truncate">{j.address}</div>
                  </div>
                  <div className="text-sm text-gold">{gbp(j.fee)}</div>
                </Card>
              ))}
            </div>
          </div>
        )
      })}
    </div>
  )
}

function JobForm({ onClose }: { onClose: () => void }) {
  const [clientName, setClientName] = useState('')
  const [address, setAddress] = useState('')
  const [type, setType] = useState<Job['type']>('changeover')
  const [fee, setFee] = useState('')
  const [date, setDate] = useState(() => {
    const d = new Date()
    return d.toISOString().slice(0, 10)
  })
  const [notes, setNotes] = useState('')

  const submit = async () => {
    const f = parseFloat(fee)
    if (!clientName.trim() || !address.trim() || !Number.isFinite(f)) return
    await db.jobs.add({
      id: uid(),
      clientName: clientName.trim(),
      address: address.trim(),
      date: startOfDay(new Date(date)),
      type,
      fee: f,
      status: 'pending',
      notes: notes.trim() || undefined
    })
    haptic('success')
    onClose()
  }

  return (
    <div className="fixed inset-0 z-40 bg-forest-deep/95 backdrop-blur-sm overflow-y-auto safe-top safe-bottom">
      <div className="max-w-md mx-auto p-4 space-y-3">
        <div className="flex justify-between items-center mb-2">
          <h3 className="display-heading text-xl text-cream">New job</h3>
          <button onClick={onClose} aria-label="Close" className="btn-icon size-11">
            <X size={20} />
          </button>
        </div>
        <input
          autoFocus
          className="input-field"
          placeholder="Property / client name *"
          value={clientName}
          onChange={(e) => setClientName(e.target.value)}
        />
        <input
          className="input-field"
          placeholder="Address *"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
        />
        <input
          type="date"
          className="input-field"
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />
        <div className="flex gap-1.5">
          {(['changeover', 'deep', 'maintenance', 'other'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setType(t)}
              className={`flex-1 px-3 py-2 rounded-full text-xs capitalize ${
                type === t ? 'bg-gold text-forest-deep' : 'bg-cream/5 text-cream/70'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
        <div className="relative">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-cream-muted">£</span>
          <input
            className="input-field pl-7"
            placeholder="Fee"
            inputMode="decimal"
            value={fee}
            onChange={(e) => setFee(e.target.value.replace(/[^0-9.]/g, ''))}
          />
        </div>
        <textarea
          className="input-field py-3 min-h-[4rem]"
          placeholder="Notes (key safe, linen location, etc.)"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
        />
        <div className="flex gap-2 pt-2">
          <button onClick={onClose} className="btn-ghost flex-1">
            Cancel
          </button>
          <button onClick={submit} className="btn-primary flex-1">
            Add job
          </button>
        </div>
      </div>
    </div>
  )
}
