import { useAppStore, type MeSub } from '../store/appStore'
import Money from './Money'
import Habits from './Habits'
import Private from './Private'

const SUBS: { id: MeSub; label: string }[] = [
  { id: 'money', label: 'Money' },
  { id: 'habits', label: 'Habits' },
  { id: 'private', label: 'Private' }
]

export default function Me() {
  const sub = useAppStore((s) => s.meSub)
  const setSub = useAppStore((s) => s.setMeSub)

  return (
    <div>
      <div className="flex gap-2 mb-4">
        {SUBS.map((s) => (
          <button
            key={s.id}
            onClick={() => setSub(s.id)}
            className={`flex-1 min-h-tap rounded-2xl text-sm font-medium ${
              sub === s.id
                ? 'bg-gold text-forest-deep'
                : 'bg-cream/5 text-cream/70 border border-cream/10'
            }`}
          >
            {s.label}
          </button>
        ))}
      </div>

      {sub === 'money' && <Money />}
      {sub === 'habits' && <Habits />}
      {sub === 'private' && <Private />}
    </div>
  )
}
