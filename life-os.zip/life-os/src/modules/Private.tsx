import { useState, useEffect } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Lock, Plus, Trash2, X, Save } from 'lucide-react'
import { db, uid, type PrivateNote } from '../db/schema'
import { Card } from '../components/Card'
import { obfuscate, deobfuscate, TOKEN_PLAIN } from '../lib/crypto'
import { haptic } from '../hooks/useHaptic'

const PIN_TOKEN_KEY = 'pin_token'

export default function Private() {
  const [unlocked, setUnlocked] = useState(false)
  const [pin, setPin] = useState('')
  const [enteringPin, setEnteringPin] = useState('')
  const [error, setError] = useState('')
  const [tokenExists, setTokenExists] = useState<boolean | null>(null)

  // Check if PIN has ever been set
  useEffect(() => {
    db.kv.get(PIN_TOKEN_KEY).then((r) => setTokenExists(!!r))
  }, [])

  const setupPin = async () => {
    if (enteringPin.length < 4) {
      setError('Use at least 4 digits.')
      return
    }
    const token = obfuscate(TOKEN_PLAIN, enteringPin)
    await db.kv.put({ key: PIN_TOKEN_KEY, value: token })
    setPin(enteringPin)
    setEnteringPin('')
    setError('')
    setUnlocked(true)
    setTokenExists(true)
    haptic('success')
  }

  const tryUnlock = async () => {
    const rec = await db.kv.get(PIN_TOKEN_KEY)
    const decoded = deobfuscate(rec?.value as string, enteringPin)
    if (decoded === TOKEN_PLAIN) {
      setPin(enteringPin)
      setEnteringPin('')
      setError('')
      setUnlocked(true)
      haptic('success')
    } else {
      setError('Wrong PIN.')
      setEnteringPin('')
      haptic('warn')
    }
  }

  const lock = () => {
    setPin('')
    setUnlocked(false)
  }

  if (tokenExists === null) return null

  if (!unlocked) {
    const setting = !tokenExists
    return (
      <div className="page-enter">
        <Card prominent>
          <div className="flex items-center gap-3 mb-3">
            <div className="size-12 rounded-full bg-gold/20 text-gold flex items-center justify-center">
              <Lock size={22} />
            </div>
            <div>
              <div className="display-heading text-xl text-cream">
                {setting ? 'Set a PIN' : 'Locked'}
              </div>
              <div className="text-xs text-cream-dim">
                {setting
                  ? 'For court notes and anything sensitive. Stored locally only.'
                  : 'Enter PIN to unlock.'}
              </div>
            </div>
          </div>
          <input
            autoFocus
            type="password"
            inputMode="numeric"
            placeholder={setting ? 'New PIN (4+ digits)' : 'PIN'}
            className="input-field text-center tracking-[0.4em] text-lg"
            value={enteringPin}
            onChange={(e) => {
              setError('')
              setEnteringPin(e.target.value.replace(/[^0-9]/g, '').slice(0, 8))
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter') setting ? setupPin() : tryUnlock()
            }}
          />
          {error && <div className="text-danger text-sm mt-2">{error}</div>}
          <button
            onClick={setting ? setupPin : tryUnlock}
            className="btn-primary w-full mt-3"
            disabled={enteringPin.length < 4}
          >
            {setting ? 'Set PIN' : 'Unlock'}
          </button>
          <div className="text-xxs text-cream-muted mt-3 text-center">
            Local obfuscation only. Use phone-level security for real privacy.
          </div>
        </Card>
      </div>
    )
  }

  return <NotesList pin={pin} onLock={lock} />
}

function NotesList({ pin, onLock }: { pin: string; onLock: () => void }) {
  const notesRaw = useLiveQuery(() => db.notes.orderBy('updatedAt').reverse().toArray(), []) ?? []
  const [editing, setEditing] = useState<PrivateNote | 'new' | null>(null)

  const notes = notesRaw.map((n) => ({
    ...n,
    body: deobfuscate(n.body, pin)
  }))

  return (
    <div className="page-enter">
      <div className="flex justify-between items-center mb-4">
        <div>
          <div className="text-xxs uppercase tracking-[0.18em] text-gold/80">Private</div>
          <h2 className="display-heading text-2xl text-cream">Notes</h2>
        </div>
        <div className="flex gap-2">
          <button onClick={onLock} aria-label="Lock" className="btn-icon size-11">
            <Lock size={18} />
          </button>
          <button onClick={() => setEditing('new')} aria-label="New" className="btn-icon size-11 bg-gold text-forest-deep">
            <Plus size={18} />
          </button>
        </div>
      </div>

      {editing && (
        <NoteEditor
          pin={pin}
          note={editing === 'new' ? null : editing}
          onClose={() => setEditing(null)}
        />
      )}

      <div className="space-y-2">
        {notes.length === 0 ? (
          <Card>
            <div className="text-center text-cream-dim text-sm">
              No notes yet. Tap + to add one.
            </div>
          </Card>
        ) : (
          notes.map((n) => (
            <button
              key={n.id}
              onClick={() => setEditing(notesRaw.find((r) => r.id === n.id)!)}
              className="card p-4 w-full text-left active:scale-[0.99] transition-transform"
            >
              <div className="text-cream font-medium truncate">{n.title || '(untitled)'}</div>
              <div className="text-xs text-cream-dim mt-1 line-clamp-2 whitespace-pre-wrap">
                {n.body || '—'}
              </div>
              <div className="text-xxs text-cream-muted mt-2">
                {new Date(n.updatedAt).toLocaleDateString('en-GB')}
              </div>
            </button>
          ))
        )}
      </div>
    </div>
  )
}

function NoteEditor({
  pin,
  note,
  onClose
}: {
  pin: string
  note: PrivateNote | null
  onClose: () => void
}) {
  const [title, setTitle] = useState(note?.title ?? '')
  const [body, setBody] = useState(note ? deobfuscate(note.body, pin) : '')

  const save = async () => {
    const payload = {
      title: title.trim(),
      body: obfuscate(body, pin),
      updatedAt: Date.now()
    }
    if (note) {
      await db.notes.update(note.id, payload)
    } else {
      await db.notes.add({ id: uid(), ...payload })
    }
    haptic('success')
    onClose()
  }

  return (
    <div className="fixed inset-0 z-40 bg-forest-deep/97 backdrop-blur-sm safe-top safe-bottom flex flex-col">
      <div className="max-w-md mx-auto w-full p-4 flex-1 flex flex-col">
        <div className="flex justify-between items-center mb-3">
          <h3 className="display-heading text-lg text-cream">
            {note ? 'Edit' : 'New note'}
          </h3>
          <div className="flex gap-2">
            {note && (
              <button
                onClick={async () => {
                  await db.notes.delete(note.id)
                  haptic('warn')
                  onClose()
                }}
                aria-label="Delete"
                className="btn-icon size-11"
              >
                <Trash2 size={18} />
              </button>
            )}
            <button onClick={onClose} aria-label="Close" className="btn-icon size-11">
              <X size={18} />
            </button>
          </div>
        </div>
        <input
          autoFocus
          className="input-field mb-3"
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <textarea
          className="input-field py-3 flex-1 resize-none"
          placeholder="Write…"
          value={body}
          onChange={(e) => setBody(e.target.value)}
        />
        <button onClick={save} className="btn-primary w-full mt-3">
          <Save size={18} /> Save
        </button>
      </div>
    </div>
  )
}
