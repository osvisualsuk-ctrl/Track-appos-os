import { useState, useMemo } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Plus, Check, ShoppingCart, Coins, Minus } from 'lucide-react'
import { db, uid, type PlanItem, type MealLog } from '../db/schema'
import { startOfDay, endOfDay } from '../utils/date'
import { gbp } from '../utils/currency'
import { Card, CardButton } from '../components/Card'
import { SectionHeader } from '../components/SectionHeader'
import { haptic } from '../hooks/useHaptic'

const SLOT_ORDER: PlanItem['slot'][] = ['breakfast', 'lunch', 'dinner', 'snack']
const SLOT_LABEL: Record<PlanItem['slot'], string> = {
  breakfast: 'Breakfast',
  lunch: 'Lunch',
  dinner: 'Dinner',
  snack: 'Snack'
}

export default function Food() {
  const [view, setView] = useState<'today' | 'plan' | 'shop' | 'budget'>('today')

  const plan = useLiveQuery(() => db.plan.toArray(), []) ?? []
  const target = useLiveQuery(
    async () => ((await db.kv.get('kcal_target'))?.value as number) ?? 3200,
    []
  )
  const budget = useLiveQuery(
    async () => ((await db.kv.get('food_budget_fortnight'))?.value as number) ?? 75,
    []
  )
  const meals = useLiveQuery(
    () =>
      db.meals
        .where('ts')
        .between(startOfDay(), endOfDay(), true, true)
        .toArray(),
    []
  ) ?? []

  const eatenSlots = useMemo(() => new Set(meals.map((m) => m.slot)), [meals])
  const totalKcal = meals.reduce((s, m) => s + m.kcal, 0)
  const pct = Math.min(100, Math.round((totalKcal / (target ?? 3200)) * 100))

  const logMeal = async (p: PlanItem) => {
    const m: MealLog = {
      id: uid(),
      ts: Date.now(),
      slot: p.slot,
      name: p.name,
      kcal: p.kcal
    }
    await db.meals.add(m)
    haptic('success')
  }

  const undoMeal = async (slot: PlanItem['slot']) => {
    const m = meals.find((x) => x.slot === slot)
    if (m) {
      await db.meals.delete(m.id)
      haptic('tap')
    }
  }

  return (
    <div className="page-enter">
      <SectionHeader eyebrow="Fuel" title="Food" />

      {/* Total ring */}
      <Card prominent className="mb-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-xs uppercase tracking-wider text-cream-dim">Today</div>
            <div className="display-heading text-4xl text-cream mt-1">
              {totalKcal.toLocaleString()}
              <span className="text-cream-muted text-lg ml-1">
                / {(target ?? 3200).toLocaleString()}
              </span>
            </div>
            <div className="text-xs text-gold mt-1">{pct}% of target</div>
          </div>
          <div className="text-right">
            <div className="text-xs text-cream-dim">Remaining</div>
            <div className="display-heading text-2xl text-gold">
              {Math.max(0, (target ?? 3200) - totalKcal).toLocaleString()}
            </div>
          </div>
        </div>
        <div className="mt-3 h-2 rounded-full bg-cream/10 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-gold to-gold-glow transition-all duration-500"
            style={{ width: `${pct}%` }}
          />
        </div>
      </Card>

      {/* View tabs */}
      <div className="flex gap-2 mb-4 overflow-x-auto no-scrollbar">
        {(
          [
            ['today', 'Today'],
            ['plan', 'Plan'],
            ['shop', 'Shop'],
            ['budget', 'Budget']
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            onClick={() => setView(id)}
            className={`px-4 py-2 rounded-full text-sm whitespace-nowrap ${
              view === id
                ? 'bg-gold text-forest-deep'
                : 'bg-cream/5 text-cream/70 border border-cream/10'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {view === 'today' && (
        <div className="space-y-3">
          {SLOT_ORDER.map((slot) => {
            const item = plan.find((p) => p.slot === slot)
            if (!item) return null
            const eaten = eatenSlots.has(slot)
            return (
              <CardButton
                key={slot}
                onClick={() => (eaten ? undoMeal(slot) : logMeal(item))}
                className="flex items-center gap-3"
              >
                <div
                  className={`size-10 shrink-0 rounded-full flex items-center justify-center ${
                    eaten ? 'bg-gold text-forest-deep' : 'bg-cream/10 text-cream'
                  }`}
                >
                  {eaten ? <Check size={20} /> : <Plus size={20} />}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-xxs uppercase tracking-wider text-gold/80">
                    {SLOT_LABEL[slot]}
                  </div>
                  <div
                    className={`font-medium truncate ${eaten ? 'text-cream-muted line-through' : 'text-cream'}`}
                  >
                    {item.name}
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-cream font-medium">{item.kcal}</div>
                  <div className="text-xxs text-cream-muted">kcal</div>
                </div>
              </CardButton>
            )
          })}
          <QuickAdd />
        </div>
      )}

      {view === 'plan' && <PlanEditor plan={plan} />}
      {view === 'shop' && <ShoppingList plan={plan} eatenSlots={eatenSlots} />}
      {view === 'budget' && <Budget fortnight={budget ?? 75} />}
    </div>
  )
}

// ------- Quick add (custom snack/meal) -------
function QuickAdd() {
  const [open, setOpen] = useState(false)
  const [name, setName] = useState('')
  const [kcal, setKcal] = useState('')

  const submit = async () => {
    const k = parseInt(kcal, 10)
    if (!name.trim() || !Number.isFinite(k) || k <= 0) return
    await db.meals.add({
      id: uid(),
      ts: Date.now(),
      slot: 'snack',
      name: name.trim(),
      kcal: k
    })
    setName('')
    setKcal('')
    setOpen(false)
    haptic('success')
  }

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} className="btn-ghost w-full mt-2">
        <Plus size={18} /> Log something else
      </button>
    )
  }

  return (
    <Card className="space-y-2">
      <input
        className="input-field"
        placeholder="What did you eat?"
        value={name}
        onChange={(e) => setName(e.target.value)}
        autoFocus
      />
      <input
        className="input-field"
        placeholder="Calories"
        inputMode="numeric"
        value={kcal}
        onChange={(e) => setKcal(e.target.value.replace(/[^0-9]/g, ''))}
      />
      <div className="flex gap-2">
        <button onClick={() => setOpen(false)} className="btn-ghost flex-1">
          Cancel
        </button>
        <button onClick={submit} className="btn-primary flex-1">
          Log it
        </button>
      </div>
    </Card>
  )
}

// ------- Plan editor (read-only quick reference) -------
function PlanEditor({ plan }: { plan: PlanItem[] }) {
  return (
    <div className="space-y-3">
      {SLOT_ORDER.map((slot) => {
        const item = plan.find((p) => p.slot === slot)
        if (!item) return null
        return (
          <Card key={slot}>
            <div className="text-xxs uppercase tracking-wider text-gold/80 mb-1">
              {SLOT_LABEL[slot]} — {item.kcal} kcal
            </div>
            <div className="text-cream font-medium mb-3">{item.name}</div>
            <ul className="space-y-1.5">
              {item.ingredients.map((ing, i) => (
                <li
                  key={i}
                  className="flex justify-between text-sm border-b border-cream/5 pb-1.5 last:border-0"
                >
                  <span className="text-cream">{ing.name}</span>
                  <span className="text-cream-muted">
                    {ing.qty}
                    {ing.store && <span className="text-gold/60 ml-2">{ing.store}</span>}
                  </span>
                </li>
              ))}
            </ul>
          </Card>
        )
      })}
    </div>
  )
}

// ------- Shopping list (what you haven't eaten yet today) -------
function ShoppingList({
  plan,
  eatenSlots
}: {
  plan: PlanItem[]
  eatenSlots: Set<PlanItem['slot']>
}) {
  // Group remaining ingredients by store
  const byStore = useMemo(() => {
    const remaining = plan.filter((p) => !eatenSlots.has(p.slot))
    const map: Record<string, { name: string; qty: string; from: string }[]> = {}
    for (const p of remaining) {
      for (const ing of p.ingredients) {
        const store = ing.store ?? 'Other'
        ;(map[store] ??= []).push({ name: ing.name, qty: ing.qty, from: p.name })
      }
    }
    return map
  }, [plan, eatenSlots])

  const storeNames = Object.keys(byStore).sort()
  const isEmpty = storeNames.length === 0

  return (
    <div className="space-y-3">
      <Card>
        <div className="flex items-center gap-2 text-cream-dim text-sm">
          <ShoppingCart size={16} />
          <span>
            {isEmpty
              ? 'All meals logged — nothing outstanding.'
              : `What you still need today, grouped by store.`}
          </span>
        </div>
      </Card>
      {storeNames.map((store) => (
        <Card key={store}>
          <div className="display-heading text-lg text-gold mb-2">{store}</div>
          <ul className="space-y-1.5">
            {byStore[store].map((ing, i) => (
              <li key={i} className="flex justify-between text-sm">
                <span className="text-cream">{ing.name}</span>
                <span className="text-cream-muted">{ing.qty}</span>
              </li>
            ))}
          </ul>
        </Card>
      ))}
    </div>
  )
}

// ------- Budget (fortnightly food spend) -------
function Budget({ fortnight }: { fortnight: number }) {
  const since = Date.now() - 14 * 86400000
  const spend = useLiveQuery(
    () =>
      db.ledger
        .where('ts')
        .above(since)
        .filter((e) => e.kind === 'out' && e.category === 'Food')
        .toArray(),
    [since]
  ) ?? []

  const [amt, setAmt] = useState('')
  const [where, setWhere] = useState('Aldi')

  const total = spend.reduce((s, e) => s + e.amount, 0)
  const remaining = Math.max(0, fortnight - total)
  const over = total > fortnight

  const log = async () => {
    const v = parseFloat(amt)
    if (!Number.isFinite(v) || v <= 0) return
    await db.ledger.add({
      id: uid(),
      ts: Date.now(),
      kind: 'out',
      category: 'Food',
      amount: v,
      note: where
    })
    setAmt('')
    haptic('success')
  }

  return (
    <div className="space-y-3">
      <Card prominent>
        <div className="flex items-center gap-2 text-cream-dim text-xs uppercase tracking-wider mb-1">
          <Coins size={14} /> Fortnightly food budget
        </div>
        <div className="display-heading text-3xl text-cream">
          {gbp(total)} <span className="text-cream-muted text-lg">/ {gbp(fortnight)}</span>
        </div>
        <div className={`text-sm mt-1 ${over ? 'text-danger' : 'text-gold'}`}>
          {over ? `Over by ${gbp(total - fortnight)}` : `${gbp(remaining)} left`}
        </div>
      </Card>

      <Card>
        <div className="text-xxs uppercase tracking-wider text-gold/80 mb-2">Log a shop</div>
        <div className="flex gap-2 mb-2 flex-wrap">
          {['Aldi', 'Lidl', 'Food Warehouse', 'Booker', 'Other'].map((s) => (
            <button
              key={s}
              onClick={() => setWhere(s)}
              className={`px-3 py-2 rounded-full text-xs ${
                where === s ? 'bg-gold text-forest-deep' : 'bg-cream/5 text-cream/70'
              }`}
            >
              {s}
            </button>
          ))}
        </div>
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-cream-muted">£</span>
            <input
              className="input-field pl-7"
              placeholder="0.00"
              inputMode="decimal"
              value={amt}
              onChange={(e) => setAmt(e.target.value.replace(/[^0-9.]/g, ''))}
            />
          </div>
          <button onClick={log} className="btn-primary px-6">
            <Plus size={18} /> Add
          </button>
        </div>
      </Card>

      {spend.length > 0 && (
        <Card>
          <div className="text-xxs uppercase tracking-wider text-gold/80 mb-2">Recent</div>
          <ul className="space-y-2">
            {spend
              .slice()
              .sort((a, b) => b.ts - a.ts)
              .slice(0, 10)
              .map((e) => (
                <li key={e.id} className="flex justify-between text-sm items-center">
                  <span className="text-cream">
                    {e.note || 'Shop'}{' '}
                    <span className="text-cream-muted text-xxs ml-1">
                      {new Date(e.ts).toLocaleDateString('en-GB')}
                    </span>
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="text-cream font-medium">{gbp(e.amount)}</span>
                    <button
                      onClick={() => db.ledger.delete(e.id)}
                      aria-label="Remove"
                      className="size-7 rounded-full bg-cream/5 flex items-center justify-center"
                    >
                      <Minus size={14} />
                    </button>
                  </div>
                </li>
              ))}
          </ul>
        </Card>
      )}
    </div>
  )
}
