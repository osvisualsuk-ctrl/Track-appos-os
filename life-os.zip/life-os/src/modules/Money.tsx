import { useState, useMemo } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Plus, ArrowUpRight, ArrowDownRight, Trash2, AlertTriangle } from 'lucide-react'
import { db, uid, type LedgerEntry } from '../db/schema'
import { startOfWeek, startOfMonth } from '../utils/date'
import { gbp } from '../utils/currency'
import { Card } from '../components/Card'
import { haptic } from '../hooks/useHaptic'

const IN_CATS = ['UC', 'Inhance', 'R&R', 'Other in']
const OUT_CATS = ['Food', 'Fuel', 'Gear', 'Bills', 'Joints', 'Other out']

const FOOD_FORTNIGHT_LIMIT = 75
const FUEL_WEEK_LIMIT = 40

export default function Money() {
  const [open, setOpen] = useState<'in' | 'out' | null>(null)
  const entries = useLiveQuery(() => db.ledger.orderBy('ts').reverse().toArray(), []) ?? []

  const weekStart = startOfWeek()
  const monthStart = startOfMonth()

  const totals = useMemo(() => {
    const w = entries.filter((e) => e.ts >= weekStart)
    const m = entries.filter((e) => e.ts >= monthStart)
    return {
      weekIn: w.filter((e) => e.kind === 'in').reduce((s, e) => s + e.amount, 0),
      weekOut: w.filter((e) => e.kind === 'out').reduce((s, e) => s + e.amount, 0),
      monthIn: m.filter((e) => e.kind === 'in').reduce((s, e) => s + e.amount, 0),
      monthOut: m.filter((e) => e.kind === 'out').reduce((s, e) => s + e.amount, 0)
    }
  }, [entries, weekStart, monthStart])

  // Overspend flags
  const foodSpend = entries
    .filter((e) => e.kind === 'out' && e.category === 'Food' && e.ts >= Date.now() - 14 * 86400000)
    .reduce((s, e) => s + e.amount, 0)
  const fuelSpend = entries
    .filter((e) => e.kind === 'out' && e.category === 'Fuel' && e.ts >= weekStart)
    .reduce((s, e) => s + e.amount, 0)
  const flags: { label: string; over: number }[] = []
  if (foodSpend > FOOD_FORTNIGHT_LIMIT)
    flags.push({ label: `Food (fortnight)`, over: foodSpend - FOOD_FORTNIGHT_LIMIT })
  if (fuelSpend > FUEL_WEEK_LIMIT)
    flags.push({ label: `Fuel (week)`, over: fuelSpend - FUEL_WEEK_LIMIT })

  return (
    <div className="page-enter">
      <div className="grid grid-cols-2 gap-3 mb-4">
        <Card prominent>
          <div className="text-xxs uppercase tracking-wider text-cream-dim">This week</div>
          <div className="display-heading text-2xl text-cream mt-1">
            {gbp(totals.weekIn - totals.weekOut)}
          </div>
          <div className="text-xxs mt-1">
            <span className="text-ok">+{gbp(totals.weekIn)}</span>
            {' / '}
            <span className="text-danger">-{gbp(totals.weekOut)}</span>
          </div>
        </Card>
        <Card prominent>
          <div className="text-xxs uppercase tracking-wider text-cream-dim">This month</div>
          <div className="display-heading text-2xl text-cream mt-1">
            {gbp(totals.monthIn - totals.monthOut)}
          </div>
          <div className="text-xxs mt-1">
            <span className="text-ok">+{gbp(totals.monthIn)}</span>
            {' / '}
            <span className="text-danger">-{gbp(totals.monthOut)}</span>
          </div>
        </Card>
      </div>

      {flags.length > 0 && (
        <Card className="mb-4 border-danger/40">
          <div className="flex items-start gap-2 text-sm">
            <AlertTriangle size={16} className="text-danger mt-0.5 shrink-0" />
            <div>
              <div className="text-cream font-medium mb-0.5">Heads up</div>
              {flags.map((f, i) => (
                <div key={i} className="text-cream-dim text-xs">
                  {f.label} over by <span className="text-danger">{gbp(f.over)}</span>
                </div>
              ))}
            </div>
          </div>
        </Card>
      )}

      <div className="grid grid-cols-2 gap-3 mb-4">
        <button onClick={() => setOpen('in')} className="btn-primary">
          <ArrowDownRight size={18} /> Money in
        </button>
        <button
          onClick={() => setOpen('out')}
          className="btn-ghost bg-danger/15 border-danger/30 text-cream"
        >
          <ArrowUpRight size={18} /> Money out
        </button>
      </div>

      {open && <LedgerForm kind={open} onClose={() => setOpen(null)} />}

      <div className="space-y-2">
        {entries.length === 0 ? (
          <Card>
            <div className="text-center text-cream-dim text-sm">
              No entries yet — log your first one above.
            </div>
          </Card>
        ) : (
          entries.slice(0, 40).map((e) => <LedgerRow key={e.id} e={e} />)
        )}
      </div>
    </div>
  )
}

function LedgerRow({ e }: { e: LedgerEntry }) {
  return (
    <Card className="flex items-center gap-3">
      <div
        className={`size-9 rounded-full flex items-center justify-center shrink-0 ${
          e.kind === 'in' ? 'bg-ok/15 text-ok' : 'bg-danger/15 text-danger'
        }`}
      >
        {e.kind === 'in' ? <ArrowDownRight size={16} /> : <ArrowUpRight size={16} />}
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-cream text-sm font-medium truncate">{e.category}</div>
        <div className="text-xxs text-cream-muted">
          {new Date(e.ts).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
          {e.note && <span className="ml-1">· {e.note}</span>}
        </div>
      </div>
      <div className={`font-medium ${e.kind === 'in' ? 'text-ok' : 'text-cream'}`}>
        {e.kind === 'in' ? '+' : '-'}
        {gbp(e.amount)}
      </div>
      <button
        onClick={() => db.ledger.delete(e.id)}
        aria-label="Delete"
        className="size-8 rounded-full bg-cream/5 flex items-center justify-center text-cream/60"
      >
        <Trash2 size={14} />
      </button>
    </Card>
  )
}

function LedgerForm({ kind, onClose }: { kind: 'in' | 'out'; onClose: () => void }) {
  const cats = kind === 'in' ? IN_CATS : OUT_CATS
  const [cat, setCat] = useState(cats[0])
  const [amt, setAmt] = useState('')
  const [note, setNote] = useState('')

  const submit = async () => {
    const v = parseFloat(amt)
    if (!Number.isFinite(v) || v <= 0) return
    await db.ledger.add({
      id: uid(),
      ts: Date.now(),
      kind,
      category: cat,
      amount: v,
      note: note.trim() || undefined
    })
    haptic('success')
    onClose()
  }

  return (
    <div className="fixed inset-0 z-40 bg-forest-deep/95 backdrop-blur-sm safe-top safe-bottom">
      <div className="max-w-md mx-auto p-4 space-y-3">
        <h3 className="display-heading text-xl text-cream mb-2">
          {kind === 'in' ? 'Money in' : 'Money out'}
        </h3>
        <div className="flex flex-wrap gap-1.5">
          {cats.map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={`px-3 py-2 rounded-full text-xs ${
                cat === c ? 'bg-gold text-forest-deep' : 'bg-cream/5 text-cream/70'
              }`}
            >
              {c}
            </button>
          ))}
        </div>
        <div className="relative">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-cream-muted">£</span>
          <input
            autoFocus
            className="input-field pl-7"
            placeholder="0.00"
            inputMode="decimal"
            value={amt}
            onChange={(e) => setAmt(e.target.value.replace(/[^0-9.]/g, ''))}
          />
        </div>
        <input
          className="input-field"
          placeholder="Note (optional)"
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
        <div className="flex gap-2 pt-2">
          <button onClick={onClose} className="btn-ghost flex-1">
            Cancel
          </button>
          <button onClick={submit} className="btn-primary flex-1">
            <Plus size={18} /> Log
          </button>
        </div>
      </div>
    </div>
  )
}
