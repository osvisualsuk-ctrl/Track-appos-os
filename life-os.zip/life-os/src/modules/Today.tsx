import { useMemo, useState, useEffect } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import {
  Check,
  Flame,
  Droplets,
  Sparkles,
  UtensilsCrossed,
  Briefcase,
  ArrowRight,
  RefreshCw,
  Zap
} from 'lucide-react'
import {
  db,
  uid,
  type Chore,
  type Client,
  type Job,
  type PlanItem,
  type MealLog
} from '../db/schema'
import { startOfDay, endOfDay, daysSince, relativeDay, ymd } from '../utils/date'
import { gbp } from '../utils/currency'
import { Card, CardButton } from '../components/Card'
import { useAppStore } from '../store/appStore'
import { haptic } from '../hooks/useHaptic'

// ------- Prioritisation helpers -------

const choreUrgency = (c: Chore) => {
  const d = daysSince(c.lastDone)
  if (!Number.isFinite(d)) return 999
  return d - c.intervalDays // higher = more overdue
}

// Pick the top business task. Priorities (Inhance first if active leads):
// 1. Inhance client whose nextAction exists and last contact > 3 days
// 2. Any Inhance lead/contacted with no lastContact ever
// 3. Inhance client by oldest lastContact
// 4. Otherwise nothing
const pickTopBusiness = (clients: Client[]) => {
  const active = clients.filter((c) => c.business === 'inhance' && c.stage !== 'invoiced')
  if (active.length === 0) return null
  const scored = active.map((c) => {
    const d = daysSince(c.lastContact)
    const hasAction = c.nextAction ? 1 : 0
    // higher score = needs attention more
    const score = (Number.isFinite(d) ? d : 30) + hasAction * 2
    return { c, score }
  })
  scored.sort((a, b) => b.score - a.score)
  return scored[0].c
}

// Pick next meal slot the user hasn't logged yet
const pickNextMeal = (plan: PlanItem[], todaysMeals: MealLog[]) => {
  const eaten = new Set(todaysMeals.map((m) => m.slot))
  const order: PlanItem['slot'][] = ['breakfast', 'lunch', 'dinner', 'snack']
  for (const s of order) {
    if (!eaten.has(s)) return plan.find((p) => p.slot === s) ?? null
  }
  return null
}

// 5-minute wins — small things, picked round-robin
const FIVE_MIN_WINS = [
  { label: 'Drink a glass of water', action: 'water' as const },
  { label: 'Empty the bin', action: 'chore-bins' as const },
  { label: 'Send one follow-up message', action: 'inhance' as const },
  { label: 'Wipe down the kitchen surfaces', action: 'chore-wipe' as const },
  { label: 'Take a 5-min walk outside', action: 'walk' as const },
  { label: 'Reply to one outstanding text', action: 'reply' as const },
  { label: 'Make the bed', action: 'bed' as const }
]

export default function Today() {
  const setTab = useAppStore((s) => s.setTab)
  const setBusinessSub = useAppStore((s) => s.setBusinessSub)
  const refreshSeed = useAppStore((s) => s.refreshSeed)
  const bumpRefresh = useAppStore((s) => s.bumpRefresh)

  // -------- Pull-to-refresh + tap-to-refresh --------
  const [pullY, setPullY] = useState(0)
  const [pulling, setPulling] = useState(false)

  useEffect(() => {
    let startY: number | null = null
    let isPulling = false

    const onStart = (e: TouchEvent) => {
      if (window.scrollY > 0) return
      startY = e.touches[0].clientY
      isPulling = true
    }
    const onMove = (e: TouchEvent) => {
      if (!isPulling || startY === null) return
      const dy = e.touches[0].clientY - startY
      if (dy > 0) {
        setPulling(true)
        setPullY(Math.min(80, dy * 0.5))
      }
    }
    const onEnd = () => {
      if (!isPulling) return
      isPulling = false
      startY = null
      if (pullY > 50) {
        haptic('success')
        bumpRefresh()
      }
      setPulling(false)
      setPullY(0)
    }
    window.addEventListener('touchstart', onStart, { passive: true })
    window.addEventListener('touchmove', onMove, { passive: true })
    window.addEventListener('touchend', onEnd)
    return () => {
      window.removeEventListener('touchstart', onStart)
      window.removeEventListener('touchmove', onMove)
      window.removeEventListener('touchend', onEnd)
    }
  }, [pullY, bumpRefresh])

  // -------- Data --------
  const chores = useLiveQuery(() => db.chores.toArray(), []) ?? []
  const clients = useLiveQuery(() => db.clients.toArray(), []) ?? []
  const plan = useLiveQuery(() => db.plan.toArray(), []) ?? []
  const todaysMeals = useLiveQuery(
    () => db.meals.where('ts').between(startOfDay(), endOfDay(), true, true).toArray(),
    []
  ) ?? []
  const todaysJobs = useLiveQuery(
    () => db.jobs.where('date').between(startOfDay(), endOfDay(), true, true).toArray(),
    []
  ) ?? []
  const todaysHabits = useLiveQuery(
    () => db.habits.where('date').equals(ymd()).toArray(),
    []
  ) ?? []
  const kcalTarget = useLiveQuery(
    async () => ((await db.kv.get('kcal_target'))?.value as number) ?? 3200,
    []
  ) ?? 3200

  // -------- Derived top picks --------
  const topChore = useMemo(() => {
    const sorted = chores.slice().sort((a, b) => choreUrgency(b) - choreUrgency(a))
    return sorted.find((c) => choreUrgency(c) >= 0) ?? sorted[0] ?? null
  }, [chores, refreshSeed])

  const topClient = useMemo(() => pickTopBusiness(clients), [clients, refreshSeed])
  const nextMeal = useMemo(
    () => pickNextMeal(plan, todaysMeals),
    [plan, todaysMeals, refreshSeed]
  )

  const fiveMinWin = useMemo(() => {
    const idx = (Math.floor(Date.now() / 60000) + refreshSeed) % FIVE_MIN_WINS.length
    return FIVE_MIN_WINS[idx]
  }, [refreshSeed])

  // Counters
  const kcal = todaysMeals.reduce((s, m) => s + m.kcal, 0)
  const water = todaysHabits.filter((h) => h.kind === 'water').reduce((s, h) => s + h.count, 0)
  const joints = todaysHabits.filter((h) => h.kind === 'joint').reduce((s, h) => s + h.count, 0)
  const pendingJobs = todaysJobs.filter((j) => j.status === 'pending').length

  // -------- Actions --------
  const eatMeal = async () => {
    if (!nextMeal) return
    await db.meals.add({
      id: uid(),
      ts: Date.now(),
      slot: nextMeal.slot,
      name: nextMeal.name,
      kcal: nextMeal.kcal
    })
    haptic('success')
  }
  const doChore = async () => {
    if (!topChore) return
    await db.chores.update(topChore.id, { lastDone: Date.now() })
    haptic('success')
  }
  const logWater = async () => {
    await db.habits.add({
      id: uid(),
      ts: Date.now(),
      date: ymd(),
      kind: 'water',
      count: 1
    })
    haptic('tap')
  }
  const logJoint = async () => {
    await db.habits.add({
      id: uid(),
      ts: Date.now(),
      date: ymd(),
      kind: 'joint',
      count: 1
    })
    haptic('tap')
  }

  const goToBusiness = (sub: 'inhance' | 'rr') => {
    setBusinessSub(sub)
    setTab('business')
  }

  const greeting = useMemo(() => {
    const h = new Date().getHours()
    if (h < 5) return 'Late one'
    if (h < 12) return 'Morning'
    if (h < 17) return 'Afternoon'
    if (h < 21) return 'Evening'
    return 'Night'
  }, [])

  return (
    <div className="page-enter relative">
      {/* Pull indicator */}
      <div
        className="flex items-center justify-center text-gold transition-all overflow-hidden"
        style={{ height: pulling ? pullY : 0 }}
      >
        <RefreshCw
          size={20}
          className={pullY > 50 ? 'rotate-180 transition-transform' : 'transition-transform'}
        />
      </div>

      {/* Header */}
      <div className="flex items-end justify-between mb-4">
        <div>
          <div className="text-xxs uppercase tracking-[0.18em] text-gold/80">
            {greeting}, Charlie
          </div>
          <h1 className="display-heading text-3xl text-cream leading-tight">
            What's next.
          </h1>
        </div>
        <button onClick={bumpRefresh} aria-label="Re-prioritise" className="btn-icon size-11">
          <RefreshCw size={18} />
        </button>
      </div>

      <div className="space-y-3 stagger">
        {/* Next meal */}
        {nextMeal ? (
          <CardButton prominent onClick={eatMeal} className="flex items-center gap-3">
            <div className="size-12 rounded-full bg-gold/20 text-gold flex items-center justify-center shrink-0">
              <UtensilsCrossed size={22} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xxs uppercase tracking-wider text-gold/80">
                Next meal — {nextMeal.slot}
              </div>
              <div className="display-heading text-lg text-cream truncate">
                {nextMeal.name}
              </div>
              <div className="text-xs text-cream-dim">{nextMeal.kcal} kcal · tap to log</div>
            </div>
            <Check size={20} className="text-gold shrink-0" />
          </CardButton>
        ) : (
          <Card className="flex items-center gap-3">
            <div className="size-12 rounded-full bg-ok/20 text-ok flex items-center justify-center shrink-0">
              <Check size={22} />
            </div>
            <div>
              <div className="text-xxs uppercase tracking-wider text-ok">All meals logged</div>
              <div className="text-cream text-sm">{kcal.toLocaleString()} kcal today.</div>
            </div>
          </Card>
        )}

        {/* Top chore */}
        {topChore && (
          <CardButton onClick={doChore} className="flex items-center gap-3">
            <div className="size-12 rounded-full bg-cream/10 flex items-center justify-center text-xl shrink-0">
              {topChore.emoji ?? <Sparkles size={20} />}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xxs uppercase tracking-wider text-gold/80">Tidy</div>
              <div className="text-cream font-medium truncate">{topChore.name}</div>
              <div className="text-xs text-cream-dim">
                {relativeDay(topChore.lastDone)} · every {topChore.intervalDays}d
              </div>
            </div>
            <Check size={20} className="text-gold shrink-0" />
          </CardButton>
        )}

        {/* Top business */}
        {topClient ? (
          <CardButton
            onClick={() => goToBusiness('inhance')}
            className="flex items-center gap-3"
          >
            <div className="size-12 rounded-full bg-cream/10 text-gold flex items-center justify-center shrink-0">
              <Briefcase size={20} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xxs uppercase tracking-wider text-gold/80">
                Inhance — {topClient.stage}
              </div>
              <div className="text-cream font-medium truncate">{topClient.name}</div>
              <div className="text-xs text-cream-dim truncate">
                {topClient.nextAction ?? `Last contact ${relativeDay(topClient.lastContact)}`}
              </div>
            </div>
            <ArrowRight size={20} className="text-cream-muted shrink-0" />
          </CardButton>
        ) : null}

        {/* R&R jobs today */}
        {pendingJobs > 0 && (
          <CardButton onClick={() => goToBusiness('rr')} className="flex items-center gap-3">
            <div className="size-12 rounded-full bg-cream/10 text-gold flex items-center justify-center shrink-0">
              <Briefcase size={20} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xxs uppercase tracking-wider text-gold/80">R&R today</div>
              <div className="text-cream font-medium">
                {pendingJobs} job{pendingJobs > 1 ? 's' : ''} pending
              </div>
              <div className="text-xs text-cream-dim">
                {gbp(
                  todaysJobs.filter((j) => j.status === 'pending').reduce((s, j) => s + j.fee, 0)
                )}{' '}
                outstanding
              </div>
            </div>
            <ArrowRight size={20} className="text-cream-muted shrink-0" />
          </CardButton>
        )}

        {/* 5-min win */}
        <Card>
          <div className="flex items-start gap-3">
            <div className="size-12 rounded-full bg-gold/15 text-gold flex items-center justify-center shrink-0">
              <Zap size={20} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xxs uppercase tracking-wider text-gold/80">5-min win</div>
              <div className="text-cream">{fiveMinWin.label}</div>
            </div>
            <button
              onClick={() => {
                bumpRefresh()
                haptic('tap')
              }}
              aria-label="Different one"
              className="btn-icon size-9"
            >
              <RefreshCw size={14} />
            </button>
          </div>
        </Card>

        {/* Counters row */}
        <div className="grid grid-cols-3 gap-2">
          <button onClick={() => setTab('food')} className="card p-3 text-left">
            <div className="text-xxs uppercase tracking-wider text-gold/80">kcal</div>
            <div className="display-heading text-xl text-cream">{kcal.toLocaleString()}</div>
            <div className="text-xxs text-cream-muted">/ {kcalTarget.toLocaleString()}</div>
          </button>
          <button
            onClick={logWater}
            className="card p-3 text-left active:scale-[0.97] transition-transform"
          >
            <div className="text-xxs uppercase tracking-wider text-gold/80 flex items-center gap-1">
              <Droplets size={11} /> water
            </div>
            <div className="display-heading text-xl text-cream">{water}</div>
            <div className="text-xxs text-cream-muted">tap +1</div>
          </button>
          <button
            onClick={logJoint}
            className="card p-3 text-left active:scale-[0.97] transition-transform"
          >
            <div className="text-xxs uppercase tracking-wider text-gold/80 flex items-center gap-1">
              <Flame size={11} /> joints
            </div>
            <div className="display-heading text-xl text-cream">{joints}</div>
            <div className="text-xxs text-cream-muted">tap +1</div>
          </button>
        </div>
      </div>
    </div>
  )
}
