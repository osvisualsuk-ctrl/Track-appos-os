import { useMemo } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Check, RotateCcw } from 'lucide-react'
import { db, type Chore } from '../db/schema'
import { daysSince, relativeDay } from '../utils/date'
import { Card, CardButton } from '../components/Card'
import { SectionHeader } from '../components/SectionHeader'
import { EmptyState } from '../components/EmptyState'
import { haptic } from '../hooks/useHaptic'

// Overdue score: how many intervals past due (negative = ahead of schedule)
const overdueScore = (c: Chore) => {
  const d = daysSince(c.lastDone)
  if (!Number.isFinite(d)) return Infinity
  return d - c.intervalDays
}

const isDueOrOverdue = (c: Chore) => overdueScore(c) >= 0

export default function Tidy() {
  const chores = useLiveQuery(() => db.chores.toArray(), []) ?? []

  const sorted = useMemo(
    () => chores.slice().sort((a, b) => overdueScore(b) - overdueScore(a)),
    [chores]
  )
  const due = sorted.filter(isDueOrOverdue)
  const onTrack = sorted.filter((c) => !isDueOrOverdue(c))
  const next = due[0]

  const markDone = async (c: Chore) => {
    await db.chores.update(c.id, { lastDone: Date.now() })
    haptic('success')
  }

  const reset = async (c: Chore) => {
    await db.chores.update(c.id, { lastDone: null })
    haptic('tap')
  }

  return (
    <div className="page-enter">
      <SectionHeader eyebrow="Reset the flat" title="Tidy" />

      {next ? (
        <Card prominent className="mb-4">
          <div className="text-xxs uppercase tracking-wider text-gold/80 mb-1">
            Next move
          </div>
          <div className="flex items-center gap-3 mt-1">
            {next.emoji && <span className="text-3xl">{next.emoji}</span>}
            <div className="flex-1 min-w-0">
              <div className="display-heading text-xl text-cream truncate">
                {next.name}
              </div>
              <div className="text-xs text-cream-dim">
                Last done {relativeDay(next.lastDone)} · every {next.intervalDays}d
              </div>
            </div>
          </div>
          <button onClick={() => markDone(next)} className="btn-primary w-full mt-4">
            <Check size={18} /> Done
          </button>
        </Card>
      ) : (
        <EmptyState
          title="Flat's on top of itself"
          hint="Nothing due. Have a brew."
        />
      )}

      {due.length > 1 && (
        <>
          <div className="text-xxs uppercase tracking-[0.18em] text-gold/70 mt-6 mb-2">
            Also due
          </div>
          <div className="space-y-2">
            {due.slice(1).map((c) => (
              <CardButton
                key={c.id}
                onClick={() => markDone(c)}
                className="flex items-center gap-3"
              >
                <div className="size-10 rounded-full bg-cream/10 flex items-center justify-center text-xl shrink-0">
                  {c.emoji ?? '·'}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-cream font-medium truncate">{c.name}</div>
                  <div className="text-xxs text-cream-muted">
                    {relativeDay(c.lastDone)} · every {c.intervalDays}d
                  </div>
                </div>
                <div className="size-9 rounded-full bg-gold/15 text-gold flex items-center justify-center shrink-0">
                  <Check size={18} />
                </div>
              </CardButton>
            ))}
          </div>
        </>
      )}

      {onTrack.length > 0 && (
        <>
          <div className="text-xxs uppercase tracking-[0.18em] text-cream/40 mt-6 mb-2">
            On track
          </div>
          <div className="space-y-2">
            {onTrack.map((c) => (
              <Card key={c.id} className="flex items-center gap-3 opacity-70">
                <div className="size-10 rounded-full bg-cream/5 flex items-center justify-center text-xl shrink-0">
                  {c.emoji ?? '·'}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-cream/80 truncate">{c.name}</div>
                  <div className="text-xxs text-cream-muted">
                    {relativeDay(c.lastDone)} · every {c.intervalDays}d
                  </div>
                </div>
                <button
                  onClick={() => reset(c)}
                  aria-label="Reset"
                  className="size-9 rounded-full bg-cream/5 text-cream/60 flex items-center justify-center"
                >
                  <RotateCcw size={16} />
                </button>
              </Card>
            ))}
          </div>
        </>
      )}
    </div>
  )
}
