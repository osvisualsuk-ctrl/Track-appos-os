import { useMemo } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Plus, Minus, Dumbbell, Droplets, Pill, Flame } from 'lucide-react'
import { db, uid, type HabitLog } from '../db/schema'
import { ymd, startOfWeek } from '../utils/date'
import { Card } from '../components/Card'
import { haptic } from '../hooks/useHaptic'

type Kind = HabitLog['kind']

const HABITS: { kind: Kind; label: string; Icon: typeof Dumbbell; target?: number; unit: string }[] = [
  { kind: 'gym', label: 'Gym', Icon: Dumbbell, target: 4, unit: 'sessions/wk' },
  { kind: 'water', label: 'Water', Icon: Droplets, target: 8, unit: 'glasses' },
  { kind: 'joint', label: 'Joints', Icon: Flame, unit: 'today' },
  { kind: 'supplement', label: 'Supplements', Icon: Pill, target: 1, unit: 'today' }
]

export default function Habits() {
  const all = useLiveQuery(() => db.habits.toArray(), []) ?? []
  const today = ymd()
  const weekStart = startOfWeek()

  const totals = useMemo(() => {
    const t: Record<Kind, { today: number; week: number }> = {
      gym: { today: 0, week: 0 },
      water: { today: 0, week: 0 },
      joint: { today: 0, week: 0 },
      supplement: { today: 0, week: 0 }
    }
    for (const h of all) {
      if (h.date === today) t[h.kind].today += h.count
      if (h.ts >= weekStart) t[h.kind].week += h.count
    }
    return t
  }, [all, today, weekStart])

  // Joints streak: count of consecutive days at or below "yesterday's target".
  // Light-touch: just show the gentle direction. Never shame.
  const joints7d = useMemo(() => {
    const days: { date: string; count: number }[] = []
    for (let i = 6; i >= 0; i--) {
      const d = new Date()
      d.setDate(d.getDate() - i)
      const k = ymd(d)
      days.push({ date: k, count: all.filter((h) => h.kind === 'joint' && h.date === k).reduce((s, h) => s + h.count, 0) })
    }
    return days
  }, [all])

  const log = async (kind: Kind, delta = 1) => {
    if (delta < 0) {
      // Remove most recent of today for this kind
      const todays = all
        .filter((h) => h.kind === kind && h.date === today)
        .sort((a, b) => b.ts - a.ts)
      if (todays[0]) {
        await db.habits.delete(todays[0].id)
        haptic('tap')
      }
      return
    }
    await db.habits.add({
      id: uid(),
      ts: Date.now(),
      date: today,
      kind,
      count: 1
    })
    haptic(kind === 'gym' ? 'success' : 'tap')
  }

  return (
    <div className="page-enter space-y-3">
      {HABITS.map((h) => {
        const t = totals[h.kind]
        const isWeekly = h.kind === 'gym'
        const value = isWeekly ? t.week : t.today
        const onTarget = h.target ? value >= h.target : false
        return (
          <Card key={h.kind}>
            <div className="flex items-center gap-3">
              <div
                className={`size-12 rounded-full flex items-center justify-center shrink-0 ${
                  onTarget ? 'bg-gold/20 text-gold' : 'bg-cream/5 text-cream/80'
                }`}
              >
                <h.Icon size={20} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-cream font-medium">{h.label}</div>
                <div className="text-xs text-cream-dim">
                  {value}
                  {h.target && ` / ${h.target}`} {h.unit}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => log(h.kind, -1)}
                  aria-label="Decrement"
                  className="size-11 rounded-full bg-cream/5 flex items-center justify-center"
                  disabled={value === 0}
                >
                  <Minus size={18} className={value === 0 ? 'text-cream/30' : 'text-cream'} />
                </button>
                <button
                  onClick={() => log(h.kind, +1)}
                  aria-label="Increment"
                  className="size-11 rounded-full bg-gold text-forest-deep flex items-center justify-center"
                >
                  <Plus size={18} />
                </button>
              </div>
            </div>
          </Card>
        )
      })}

      <Card>
        <div className="text-xxs uppercase tracking-wider text-gold/80 mb-3">
          Joints — last 7 days
        </div>
        <div className="flex items-end justify-between gap-1 h-20">
          {joints7d.map((d, i) => {
            const max = Math.max(1, ...joints7d.map((x) => x.count))
            const h = (d.count / max) * 100
            const isToday = i === joints7d.length - 1
            return (
              <div key={d.date} className="flex-1 flex flex-col items-center gap-1">
                <div className="flex-1 w-full flex items-end">
                  <div
                    className={`w-full rounded-t ${isToday ? 'bg-gold' : 'bg-gold/30'}`}
                    style={{ height: `${h}%`, minHeight: d.count > 0 ? '6px' : '0' }}
                  />
                </div>
                <div className={`text-xxs ${isToday ? 'text-gold' : 'text-cream-muted'}`}>
                  {d.count}
                </div>
              </div>
            )
          })}
        </div>
        <div className="text-xxs text-cream-muted mt-3 text-center">
          No targets, no shame. Just the trend.
        </div>
      </Card>
    </div>
  )
}
