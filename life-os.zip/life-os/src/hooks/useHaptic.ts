// Tiny haptic helper. Vibration API is supported on Android (S23 ✅).
// Use sparingly: completion taps and confirmations only.

export const haptic = (pattern: 'tap' | 'success' | 'warn' = 'tap') => {
  if (typeof navigator === 'undefined' || !('vibrate' in navigator)) return
  const v = navigator.vibrate.bind(navigator)
  if (pattern === 'tap') v(8)
  else if (pattern === 'success') v([10, 30, 12])
  else if (pattern === 'warn') v([20, 40, 20])
}
