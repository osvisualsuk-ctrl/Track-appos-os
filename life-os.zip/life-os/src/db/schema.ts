import Dexie, { type Table } from 'dexie'

// ---------- Types ----------

export type ID = string

export interface MealLog {
  id: ID
  ts: number // epoch ms
  slot: 'breakfast' | 'lunch' | 'dinner' | 'snack'
  name: string
  kcal: number
}

export interface PlanItem {
  id: ID
  slot: 'breakfast' | 'lunch' | 'dinner' | 'snack'
  name: string
  kcal: number
  ingredients: { name: string; qty: string; store?: string }[]
}

export interface Chore {
  id: ID
  name: string
  intervalDays: number // how often it needs doing
  lastDone: number | null // epoch ms, null = never
  emoji?: string
}

export interface Client {
  id: ID
  name: string
  business: 'inhance' | 'rr'
  location?: string
  shootType?: string
  stage: 'lead' | 'contacted' | 'booked' | 'shot' | 'delivered' | 'invoiced'
  subscription?: 'none' | 'monthly' | 'quarterly'
  nextAction?: string
  lastContact: number | null
  notes?: string
  createdAt: number
}

export interface Job {
  id: ID
  clientName: string
  address: string
  postcode?: string
  date: number // day this job is for (epoch ms, start of day)
  type: 'changeover' | 'deep' | 'maintenance' | 'other'
  fee: number
  status: 'pending' | 'done'
  notes?: string
}

export interface LedgerEntry {
  id: ID
  ts: number
  kind: 'in' | 'out'
  category: string // e.g. "UC", "Inhance", "R&R", "Food", "Fuel", "Gear", "Other"
  amount: number // pounds
  note?: string
}

export interface HabitLog {
  id: ID
  ts: number // epoch ms
  date: string // YYYY-MM-DD for easy querying
  kind: 'joint' | 'gym' | 'water' | 'supplement'
  count: number // for water (glasses), joints, supplements; gym = 1
  note?: string
}

export interface PrivateNote {
  id: ID
  title: string
  body: string // encrypted with PIN-derived key (XOR + base64 — local-only obfuscation)
  updatedAt: number
}

export interface KV {
  key: string
  value: unknown
}

// ---------- Database ----------

class LifeOSDB extends Dexie {
  meals!: Table<MealLog, ID>
  plan!: Table<PlanItem, ID>
  chores!: Table<Chore, ID>
  clients!: Table<Client, ID>
  jobs!: Table<Job, ID>
  ledger!: Table<LedgerEntry, ID>
  habits!: Table<HabitLog, ID>
  notes!: Table<PrivateNote, ID>
  kv!: Table<KV, string>

  constructor() {
    super('life-os')
    this.version(1).stores({
      meals: 'id, ts, slot',
      plan: 'id, slot',
      chores: 'id, lastDone',
      clients: 'id, business, stage, lastContact',
      jobs: 'id, date, status',
      ledger: 'id, ts, kind, category',
      habits: 'id, ts, date, kind',
      notes: 'id, updatedAt',
      kv: 'key'
    })
  }
}

export const db = new LifeOSDB()

export const uid = () =>
  Date.now().toString(36) + Math.random().toString(36).slice(2, 8)
