import { db, uid, type PlanItem, type Chore, type Client, type Job } from './schema'

const startOfDay = (d = new Date()) => {
  const x = new Date(d)
  x.setHours(0, 0, 0, 0)
  return x.getTime()
}

const PLAN: Omit<PlanItem, 'id'>[] = [
  {
    slot: 'breakfast',
    name: 'Eggs on toast + PB + shake',
    kcal: 900,
    ingredients: [
      { name: 'Eggs', qty: '4', store: 'Aldi' },
      { name: 'Wholemeal bread', qty: '2 slices', store: 'Aldi' },
      { name: 'Peanut butter', qty: '2 tbsp', store: 'Aldi' },
      { name: 'Whey protein', qty: '1 scoop', store: 'Booker' },
      { name: 'Milk', qty: '350ml', store: 'Aldi' }
    ]
  },
  {
    slot: 'lunch',
    name: 'Chicken wraps',
    kcal: 1000,
    ingredients: [
      { name: 'Chicken breast', qty: '200g', store: 'Lidl' },
      { name: 'Tortilla wraps', qty: '2', store: 'Aldi' },
      { name: 'Cheese', qty: '40g', store: 'Aldi' },
      { name: 'Salad', qty: 'handful', store: 'Aldi' },
      { name: 'Mayo / hot sauce', qty: 'splash', store: 'Aldi' }
    ]
  },
  {
    slot: 'dinner',
    name: 'Beef mince + pasta or rice',
    kcal: 1100,
    ingredients: [
      { name: 'Beef mince', qty: '250g', store: 'Food Warehouse' },
      { name: 'Pasta or rice', qty: '120g dry', store: 'Aldi' },
      { name: 'Chopped tomatoes', qty: '1 tin', store: 'Aldi' },
      { name: 'Onion', qty: '1', store: 'Aldi' },
      { name: 'Garlic', qty: '2 cloves', store: 'Aldi' }
    ]
  },
  {
    slot: 'snack',
    name: 'Top-up shake or fruit',
    kcal: 200,
    ingredients: [
      { name: 'Banana', qty: '1', store: 'Aldi' },
      { name: 'Whey protein', qty: '1 scoop', store: 'Booker' }
    ]
  }
]

const CHORES: Omit<Chore, 'id'>[] = [
  { name: 'Wash up', intervalDays: 1, lastDone: null, emoji: '🍽️' },
  { name: 'Litter tray', intervalDays: 1, lastDone: null, emoji: '🐈' },
  { name: 'Take bins out (Tue)', intervalDays: 7, lastDone: null, emoji: '🗑️' },
  { name: 'Hoover flat', intervalDays: 7, lastDone: null, emoji: '🧹' },
  { name: 'Clean bathroom', intervalDays: 7, lastDone: null, emoji: '🛁' },
  { name: 'Change bedding', intervalDays: 14, lastDone: null, emoji: '🛏️' },
  { name: 'Wipe kitchen surfaces', intervalDays: 2, lastDone: null, emoji: '🧽' },
  { name: 'Mop floors', intervalDays: 14, lastDone: null, emoji: '🪣' },
  { name: 'Empty fridge / sort food', intervalDays: 7, lastDone: null, emoji: '🧊' }
]

const CLIENTS: Omit<Client, 'id' | 'createdAt'>[] = [
  {
    name: 'Scratby Static Caravan',
    business: 'inhance',
    location: 'Scratby',
    shootType: 'Airbnb listing + drone',
    stage: 'booked',
    subscription: 'none',
    nextAction: 'Confirm shoot date with owner',
    lastContact: Date.now() - 2 * 86400000,
    notes: 'Rental gear from Wex — A7 IV preferred. Bring 16-35 + 24-70.'
  },
  {
    name: 'Southwold Coastal Cottage',
    business: 'inhance',
    location: 'Southwold',
    shootType: 'Premium Airbnb media day',
    stage: 'contacted',
    subscription: 'monthly',
    nextAction: 'Send pricing PDF',
    lastContact: Date.now() - 5 * 86400000,
    notes: 'From canvassing trip. High-end host, wants editorial vibe.'
  },
  {
    name: 'The Anchor — Lowestoft',
    business: 'inhance',
    location: 'Lowestoft',
    shootType: 'Café interiors + social reels',
    stage: 'lead',
    subscription: 'none',
    nextAction: 'Walk in next Tuesday with leaflet',
    lastContact: null,
    notes: ''
  }
]

const todayStart = startOfDay()

const JOBS: Omit<Job, 'id'>[] = [
  {
    clientName: 'Seaview Cottage',
    address: '14 Marine Parade, Lowestoft',
    postcode: 'NR33 0QN',
    date: todayStart,
    type: 'changeover',
    fee: 65,
    status: 'pending',
    notes: 'Linen in airing cupboard. Key safe 4421.'
  },
  {
    clientName: 'Dune Lodge',
    address: '7 Beach Rd, Kessingland',
    postcode: 'NR33 7RW',
    date: todayStart,
    type: 'changeover',
    fee: 75,
    status: 'pending',
    notes: 'Hot tub check + restock soaps.'
  },
  {
    clientName: 'Anchor Cottage',
    address: '22 High St, Southwold',
    postcode: 'IP18 6DS',
    date: todayStart,
    type: 'deep',
    fee: 120,
    status: 'pending',
    notes: 'Full deep clean. Window cleaner booked separately.'
  }
]

export async function seedIfEmpty() {
  const seeded = await db.kv.get('seeded')
  if (seeded?.value === true) return

  await db.transaction(
    'rw',
    [db.plan, db.chores, db.clients, db.jobs, db.kv],
    async () => {
      for (const p of PLAN) await db.plan.add({ ...p, id: uid() })
      for (const c of CHORES) await db.chores.add({ ...c, id: uid() })
      for (const c of CLIENTS)
        await db.clients.add({ ...c, id: uid(), createdAt: Date.now() })
      for (const j of JOBS) await db.jobs.add({ ...j, id: uid() })
      await db.kv.put({ key: 'seeded', value: true })
      await db.kv.put({ key: 'kcal_target', value: 3200 })
      await db.kv.put({ key: 'food_budget_fortnight', value: 75 })
    }
  )
}
