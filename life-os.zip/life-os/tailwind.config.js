/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // Inhance Media palette
        forest: {
          DEFAULT: '#1a3329',
          deep: '#0d1f18',
          mid: '#244538',
          soft: '#2f5547'
        },
        cream: {
          DEFAULT: '#f5f0e6',
          dim: '#c8c0b0',
          muted: '#8a8475'
        },
        gold: {
          DEFAULT: '#c9a961',
          soft: '#a88f4f',
          glow: '#e5c87a'
        },
        danger: '#c25a4f',
        ok: '#7fb069'
      },
      fontFamily: {
        display: ['"Fraunces"', 'Georgia', 'serif'],
        sans: ['"Geist"', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'sans-serif']
      },
      fontSize: {
        // Slightly tighter scale for mobile density
        'xxs': '0.6875rem'
      },
      spacing: {
        'tap': '3.5rem' // 56px minimum tap target
      },
      borderRadius: {
        'card': '1rem'
      }
    }
  },
  plugins: []
}
